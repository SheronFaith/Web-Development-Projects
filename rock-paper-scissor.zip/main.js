const p1=document.getElementById("p1");
const p2=document.getElementById("p2");
const result=document.getElementById("result");
let pchoice,cchoice;
const choices=["rock","paper","scissor"];

function play(pchoice){
  cchoice=choices[Math.floor(Math.random()*3)];
  p1.textContent=pchoice;
  p2.textContent=cchoice;
  result.classList.remove('tie','won','lose');
 if(pchoice===cchoice){
   result.textContent='its a tie'
   result.classList.add('tie');
 }
 else if ((pchoice=='rock' && cchoice=='paper') || (pchoice=='paper' && cchoice=='scissor') || (pchoice=='scissor' && cchoice=='rock')) {
   result.textContent='you lose';
   result.classList.add('lose');
 }
else{
  result.textContent='you won';
  result.classList.add('won');
}
}