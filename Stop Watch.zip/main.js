let starttime=0;
let elapsedtime=0;
let isrunning=false;
let time;
let timer=null;

function start() {
  isrunning=true;
  if (isrunning) {
    starttime=Date.now()-elapsedtime;
    timer=setInterval(update,1);
  }
}

function stop() {
  isrunning=false;
  clearTimeout(timer);
  elapsedtime=Date.now()-starttime;
  
}

function reset() {
  isrunning=false;
  clearTimeout(timer);
  starttime=0;
  elapsedtime=0;
  document.getElementById("time").textContent='00:00:00:00';
}

function update(){
  const currenttime=Date.now();
  elapsedtime=currenttime-starttime;
  let hour=Math.floor(elapsedtime/(1000*60*60)).toString().padStart(2,0);
  let min=Math.floor((elapsedtime/(1000*60))%60).toString().padStart(2,0);
  let sec=Math.floor((elapsedtime/1000)%60).toString().padStart(2,0);
  let millisec= Math.floor(elapsedtime%1000/10).toString().padStart(2,0);
  const display=`${hour}:${min}:${sec}:${millisec}`;
  document.getElementById("time").textContent=display 
}
