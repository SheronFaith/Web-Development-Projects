function RollDice() {

const num= document.getElementById("num").value;
const DiceText = document.getElementById("DiceText");
const DiceImage = document.getElementById("DiceImage");
let random;
let val=[];
let image=[];

for (let i = 0; i < num; i++) {
  random=Math.floor(Math.random()*6)+1;
  val.push(random);
  image.push(`<img src="images/${random}.png">`);
}

DiceText.textContent=val.join(" , ");
DiceImage.innerHTML=image.join('');

}