
const min=1, max=100;
let guess,attempt=0, running=true,answer;

answer=Math.floor(Math.random()*(max-min+1)+min);

console.log(`the random number is ${answer}`);
  document.getElementById("check").onclick=function() {
    guess=document.getElementById("input").value;
  console.log(guess);
  guess=Number(guess);
  if(isNaN(guess)){
    document.getElementById("myh1").textContent=`Enter a valid number between ${min} - ${max}`;
  }
  else if(guess<min || guess>max){
    document.getElementById("myh1").textContent=`Enter a valid number between ${min} - ${max}`;
  }
  else{
    attempt++;
    if(guess<answer){
    document.getElementById("myh1").textContent=`Too low`;
    }
    else if(guess>answer){
    document.getElementById("myh1").textContent=`TOO HIGH`;
    }
    else {
    document.getElementById("myh1").textContent=`CORRECT ANSWER ! You took ${attempt} attempts`;
      running=false;
    }
   
  }}
