function clock() {
  const date= new Date();
  let hour=date.getHours();
  let meridian= hour>12?'PM':'AM';
  hour=(hour%12).toString().padStart(2,0);
  const min=date.getMinutes().toString().padStart(2,0);
  const sec=date.getSeconds().toString().padStart(2,0);
  const time=`${hour} : ${min} : ${sec} ${meridian}`;
  document.getElementById('box1').textContent=time;
}

setInterval(clock,1000);